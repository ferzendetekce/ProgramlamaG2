﻿namespace DevicesControllerApp.Models
{
    public enum Module // <-- 'class' yerine 'enum' yazdık
    {
        // Temel Operatör görevleri
        TerapiBaslat,
        HastaKayit,
        TerapiIzle,
        Raporlama,

        // Yüksek yetki gerektiren görevler
        KullaniciKayit,
        Ayarlar,
        Servis
    }
}
