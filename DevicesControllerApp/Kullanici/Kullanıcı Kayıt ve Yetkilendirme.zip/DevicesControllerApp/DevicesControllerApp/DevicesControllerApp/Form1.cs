﻿using System;
using System.Globalization; // Gerekli
using System.Threading;     // Gerekli
using System.Windows.Forms;
using DevicesControllerApp.Kullanici; // UserRegistration'ı bulmak için gerekli

namespace DevicesControllerApp
{
    public partial class Form1 : Form
    {
        // 1. UserRegistration kontrolümüz için bir değişken tut
        private UserRegistration userControl;

        public Form1()
        {
            InitializeComponent();
        }

        // 2. Form ilk yüklendiğinde (veya dil değiştiğinde) bu metodu çağıracağız
        private void LoadUserRegistrationControl()
        {
            // 3. Eğer ekranda eski bir kontrol varsa, onu kaldır ve yok et
            if (userControl != null)
            {
                this.Controls.Remove(userControl);
                userControl.Dispose();
            }

            // 4. YENİ bir UserRegistration kontrolü oluştur
            // (Bu yeni kontrol, 'InitializeComponent' yaparken
            //  Thread.CurrentThread.CurrentUICulture'daki yeni dili okuyacaktır)
            userControl = new UserRegistration();
            userControl.Dock = DockStyle.Fill; // Ekrana sığdır

            // 5. Yeni kontrolü forma ekle
            this.Controls.Add(userControl);

            // 6. Butonların önde kalmasını sağla (isteğe bağlı ama önerilir)
            btnTR.BringToFront();
            btnEN.BringToFront();
        }

        // 7. Form1 ilk açıldığında kontrolü yükle
        private void Form1_Load(object sender, EventArgs e)
        {
            LoadUserRegistrationControl();
        }

        // 8. "TR" butonuna tıklandığında
        private void btnTR_Click(object sender, EventArgs e)
        {
            ChangeLanguage("tr-TR");
        }

        // 9. "EN" butonuna tıklandığında
        private void btnEN_Click(object sender, EventArgs e)
        {
            ChangeLanguage("en-US");
        }

        // 10. Dili değiştiren ve arayüzü yenileyen ana metot
        private void ChangeLanguage(string culture)
        {
            // A. Yeni dili ayara kaydet (program tekrar açıldığında hatırlasın)
            Properties.Settings.Default.DefaultLanguage = culture;
            Properties.Settings.Default.Save();

            // B. O anki arayüz dilini değiştir
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);

            // C. Kontrolü yeni dile göre yeniden yükle
            LoadUserRegistrationControl();
        }
    }
}