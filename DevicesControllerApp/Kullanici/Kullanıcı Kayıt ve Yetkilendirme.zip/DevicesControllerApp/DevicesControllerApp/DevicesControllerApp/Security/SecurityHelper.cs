﻿using System;
using System.IO; // Path.GetRandomFileName() için
using System.Linq;

// BCrypt kütüphanesini kullanacağımızı belirtiyoruz
using BCryptNet = BCrypt.Net.BCrypt;

namespace DevicesControllerApp.Securty
{
    // 'static' yaptık, böylece new SecurityHelper() demeden direkt kullanabiliriz.
    public static class SecurityHelper
    {
        // 1. Yeni bir şifreyi HASH'lemek için metot
        public static string HashPassword(string password)
        {
            // BCrypt.Net.BCrypt.HashPassword(...) metodunu çağırır
            return BCryptNet.HashPassword(password);
        }

        // 2. Şifre sıfırlama için rastgele bir şifre üreten metot
        // (Görev belgesindeki "karmaşıklık" kuralına uyar)
        public static string GenerateRandomPassword()
        {
            // Path.GetRandomFileName() "abc123xy.ztq" gibi rastgele bir string üretir.
            // Bunu kullanarak karmaşık bir şifre elde ederiz.
            string randomChars = Path.GetRandomFileName().Replace(".", "");
            // 8 karakter + 1 Büyük Harf + 1 Rakam + 1 Özel Karakter
            return $"{randomChars.Substring(0, 8)}A1!";
        }

        // 3. TODO (Kişi 2'nin Görevi): Şifre karmaşıklık kontrolü

        public static bool IsPasswordComplex(string password)
        {
            // Görev belgesindeki kurallar
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
            {
                return false; // 1. Kural: 8 karakterden kısa olamaz
            }

            if (!password.Any(char.IsUpper))
            {
                return false; // 2. Kural: En az bir BÜYÜK harf içermeli
            }

            if (!password.Any(char.IsLower))
            {
                return false; // 3. Kural: En az bir küçük harf içermeli
            }

            if (!password.Any(char.IsDigit))
            {
                return false; // 4. Kural: En az bir rakam içermeli
            }

            // Tüm kuralları geçtiyse
            return true;
        }

        // 4. TODO (Kişi 2'nin Görevi): Veritabanı ile şifre doğrulama
        // (Login ekranı yapılırken bu metot kullanılacak)
        public static bool VerifyPassword(string password, string passwordHash)
        {
            return BCryptNet.Verify(password, passwordHash);
        }
    }
}
