﻿using System;

// Namespace'i projenizle uyumlu hale getiriyoruz
namespace DevicesControllerApp.Models
{
    // Görev belgenizdeki Roller (Admin/Operatör/Servis) için
    // bir enum (sabit liste) tanımlıyoruz.
    public enum UserRole
    {
        Admin,
        Operatör,
        Servis
    }

    public class User
    {
        // Veritabanı için benzersiz bir kimlik (ID)
        public int Id { get; set; }

        // --- Görev Belgenizdeki Form Alanları ---
        public string Username { get; set; } // Kullanıcı Adı
        public string PasswordHash { get; set; } // Şifre (Hash'lenmiş)
        public string TcPassportNo { get; set; } // TC/Pasaport No
        public string FirstName { get; set; } // Ad
        public string LastName { get; set; } // Soyad
        public UserRole Role { get; set; } // Rol (Enum olarak)
        public string Email { get; set; } // E-Posta
        public string Phone { get; set; } // Telefon
        public byte[] Photograph { get; set; } // Fotoğraf (binary data)

        // --- Görev Belgenizdeki İşlevler için ---

        // "Kullanıcı silme (Soft delete)" işlevi için
        public bool IsActive { get; set; } = true;
    }
}