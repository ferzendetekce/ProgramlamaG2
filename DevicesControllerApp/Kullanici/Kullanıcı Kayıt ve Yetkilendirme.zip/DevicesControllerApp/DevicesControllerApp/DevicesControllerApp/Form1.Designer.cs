﻿namespace DevicesControllerApp
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTR = new System.Windows.Forms.Button();
            this.btnEN = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTR
            // 
            this.btnTR.Location = new System.Drawing.Point(969, 441);
            this.btnTR.Name = "btnTR";
            this.btnTR.Size = new System.Drawing.Size(52, 32);
            this.btnTR.TabIndex = 1;
            this.btnTR.Text = "TR";
            this.btnTR.UseVisualStyleBackColor = true;
            this.btnTR.Click += new System.EventHandler(this.btnTR_Click);
            // 
            // btnEN
            // 
            this.btnEN.Location = new System.Drawing.Point(1045, 441);
            this.btnEN.Name = "btnEN";
            this.btnEN.Size = new System.Drawing.Size(50, 32);
            this.btnEN.TabIndex = 2;
            this.btnEN.Text = "EN";
            this.btnEN.UseVisualStyleBackColor = true;
            this.btnEN.Click += new System.EventHandler(this.btnEN_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1612, 927);
            this.Controls.Add(this.btnEN);
            this.Controls.Add(this.btnTR);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnTR;
        private System.Windows.Forms.Button btnEN;
    }
}

