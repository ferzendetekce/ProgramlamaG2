﻿using System.Collections.Generic;

namespace DevicesControllerApp.Models
{
    // Sistemdeki erişim kontrolü yapılacak modüller
    public enum SystemModule
    {
        TerapiBaslat,
        HastaKayit,
        TerapiIzle,
        Raporlama,
        KullaniciKayit, // Sizin modülünüz
        Ayarlar,
        Servis
    }

    /// <summary>
    /// Rol Bazlı Erişim Kontrolü (RBAC) matrisini tutan ve yetki kontrolü yapan statik sınıf.
    /// </summary>
    public static class RBACMatrix
    {
        // Anahtar: Rol (UserRole), Değer: Erişime İzin Verilen Modüllerin Listesi
        private static readonly Dictionary<UserRole, List<SystemModule>> _permissionMatrix =
            new Dictionary<UserRole, List<SystemModule>>();

        static RBACMatrix()
        {
            // İzin matrisini dolduruyoruz (Örnek bir tanımlama):

            // 1. ADMIN Rolü İzinleri (Tüm modüllere erişim)
            _permissionMatrix[UserRole.Admin] = new List<SystemModule>
            {
                SystemModule.TerapiBaslat,
                SystemModule.HastaKayit,
                SystemModule.TerapiIzle,
                SystemModule.Raporlama,
                SystemModule.KullaniciKayit,
                SystemModule.Ayarlar,
                SystemModule.Servis
            };

            // 2. OPERATÖR Rolü İzinleri (Temel operasyonlara erişim)
            _permissionMatrix[UserRole.Operatör] = new List<SystemModule>
            {
                SystemModule.TerapiBaslat,
                SystemModule.HastaKayit,
                SystemModule.TerapiIzle,
                SystemModule.Raporlama
            };

            // 3. SERVİS Rolü İzinleri (Sınırlı operasyonlar ve Servis modülüne erişim)
            _permissionMatrix[UserRole.Servis] = new List<SystemModule>
            {
                SystemModule.TerapiBaslat,
                SystemModule.TerapiIzle,
                SystemModule.Raporlama,
                SystemModule.Servis
            };
        }

        /// <summary>
        /// Belirli bir rolün belirli bir modüle erişim yetkisi olup olmadığını kontrol eder.
        /// </summary>
        /// <param name="role">Kontrol edilecek kullanıcı rolü.</param>
        /// <param name="module">Kontrol edilecek sistem modülü.</param>
        /// <returns>Erişim izni varsa true, aksi halde false.</returns>
        public static bool HasPermission(UserRole role, SystemModule module)
        {
            if (_permissionMatrix.ContainsKey(role))
            {
                return _permissionMatrix[role].Contains(module);
            }
            return false;
        }
    }
}